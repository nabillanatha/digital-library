<?php

namespace App\Models;

class Post
{
   private static $blog_posts =  [
    [
        "title" => "Judul Post Pertama",
        "slug" => "judul-post-pertama",
        "body" => "Perpustakaan adalah sekumpulan bahan pustaka, baik yang tercetak maupun rekaman yang lainnya, pada suatu tempat tertentu yang telah diatur sedemikian rupa untuk mempermudah pengguna perpustakaan mencari informasi yang diperlukannya dan yang tujuannya utamanya adalah untuk melayani kebutuhan informasi masyarakat yang dilayaninya dan bukan untuk diperdagangkan."
    ],

    [
        "title" => "Judul Post Kedua",
        "slug" => "judul-post-kedua",
        "body" => "Dalam bukunya Dictionary of The English Language, Perpustakaan adalah suatu tempat, berupa sebuah ruangan atau gedung yang berisi buku dan bahan lain untuk bacaan, studi, ataupun rujukan."
    ],
];

public static function all()
{
    return collect(self::$blog_posts);
}

public static function find($slug)
{
    $posts = static::all();
    return $posts->firstWhere('slug', $slug);
}
}
