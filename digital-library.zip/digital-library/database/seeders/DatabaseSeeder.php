<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Post;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        User::create([
            'name' => 'Nabilla Nathafelya',
            'email' => 'nabilla.nathafelya30@gmail.com',
            'password' => bcrypt('12345')

        ]);

        Category::create([
            'name' => 'Novel',
            'slug' => 'novel'
        ]);

        
        Category::create([
            'name' => 'Komik',
            'slug' => 'komik'
        ]);

        
        Category::create([
            'name' => 'Majalah',
            'slug' => 'Majalah'
        ]);

        Post::create([
            'title' => 'Persahabatan Bunga Matahari',
            'slug' => 'persahabatan-bunga-matahari',
            'excerpt' => 'Cerita pendek kehidupan yang menceritakan persahabatan dua anak perempuan berikut dikutip dari buku 20 Cerita Manis Majalah Bobo (2016) karya Widowati Wahono.',
            'body' => '<p>Cerita pendek kehidupan yang menceritakan persahabatan dua anak perempuan berikut dikutip dari buku 20 Cerita Manis Majalah Bobo (2016) karya Widowati Wahono.</p><p>Semua teman di kelas tahu aku dan Vina bersahabat karib. Mereka bilang, di mana ada Rani, di situ ada Vina. Namun ada satu perbedaan besar antara aku dan Vina. Aku dari keluarga sederhana, Vina hidup berkecukupan.</p><p>Untunglah, meski orang tuanya kaya, Vina tidak sombong. Vina bahkan betah main di rumahku yang sederhana. Selain bermain bersama, ada satu hal yang membuat Vina senang di rumahku. Ia sangat menyukai bunga matahari yang tumbuh di halaman belakang rumahku. Sudah beberapa kali Vina mencoba menanam bunga matahari di rumahnya, tetapi selalu gagal.</p>',
            'category_id' => 1,
            'user_id' => 1
        ]);

        Post::create([
             'title' => 'True Beauty',
             'category_id' => 2,
             'slug' => 'true-beauty',
             'excerpt' => 'Drama Korea True Beauty mengisahkan tentang gadis SMA bernama Lim Ju-gyeong (Moon Ga-young) yang rendah diri karena wajah dan penampilannya.',
             'body' => '<p>Drama Korea True Beauty mengisahkan tentang gadis SMA bernam
            a Lim Ju-gyeong (Moon Ga-young) yang rendah diri karena wajah dan penampilannya.
             Ia bahkan terus-menerus mendapat diskriminasi oleh keluarganya bahkan di-bully
            oleh teman-temannya karena dianggap buruk rupa. Ju-gyeong lantas berniat menguba
            h penampilannya dengan menggunakan make-up. Ju-gyeong pun selalu berusaha agar w
            ajah aslinya tidak diketahui orang lain di sekitarnya.</p><p>ebenarnya Ju-gyeong
             adalah gadis cerdas, optimis, dan selalu bersemangat. Hanya saja, make-up menja
            di satu-satunya cara untuk bisa mengembalikan kepercayaan dirinya. Kepiawaiannya
             dalam bermake-up ini menjadikan Ju-gyeong sebagai siswi tercantik di kelasnya.
            Penampilannya bak seorang dewi itu juga tidak datang dalam satu malam. Ju-gyeong
             melewati sejumlah kegagalan dan pembelajaran untuk bisa pandai ber-make-up.</p>
            <p>Ketika suatu hari, Ju-gyeong jatuh cinta dengan satu-satunya pria yang menget
            ahui wajah aslinya tanpa make up. Adalah Lee Su-ho (Cha Eun-woo) teman satu seko
            lahnya yang cerdas, pandai bermain bakset, dan berpenampilan sempurna namun meny
            impan luka emosional di masa lalu. Di sekolah itu, ada pula siswa populer bernam
            a Han Seo-hun (Hwang In-yeob), seorang pemberontak yang ternyata ramah dan memes
            ona. Di balik sikap hangatnya itu, ternyata Seo-hun menyimpan rasa terhadap Ju-g
            yeong.</p>',
            'category_id' => 2,
            'user_id' => 1
        ]);

        Post::create([
             'title' => 'Laskar Pelangi',
             'slug' => 'laskar-pelangi',
             'excerpt' => 'Bangunan itu nyaris rubuh. Dindingnya miring bersangga sebal
            ok kayu. Atapnya bocor di mana-mana. Tetapi, berpasang-pasang mata mungil menata
            p penuh harap.',
             'body' => '<p>Bangunan itu nyaris rubuh. Dindingnya miring bersangga sebal
            ok kayu. Atapnya bocor di mana-mana. Tetapi, berpasang-pasang mata mungil menata
            p penuh harap. Hendak ke mana lagikah mereka harus bersekolah selain tempat itu?
             Tak peduli seberat apa pun kondisi sekolah itu, sepuluh anak dari keluarga misk
            in itu tetap bergeming. Di dada mereka, telah menggumpal tekad untuk maju.</p><p
            >Begitu banyak hal menakjubkan yang terjadi dalam masa kecil para anggota Laskar
             Pelangi. Sebelas orang anak Melayu Belitong yang luar biasa ini tak menyerah wa
            lau keadaan tak bersimpati pada mereka. Tengoklah Lintang, seorang kuli kopra ci
            lik yang genius dan dengan senang hati bersepeda 80 kilometer pulang pergi untuk
             memuaskan dahaganya akan ilmu bahkan terkadang hanya untuk menyanyikan padamu n
            egeri di akhir jam sekolah. Atau Mahar, seorang pesuruh tukang parut kelapa seka
            ligus seniman dadakan yang imajinatif, tak logis, kreatif, dan sering diremehkan
             sahabat-sahabatnya, namun berhasil mengangkat derajat sekolah kampung mereka da
            lam karnaval 17 Agustus, dan juga sembilan orang Laskar Pelangi lain yang begitu
             bersemangat dalam menjalani hidup dan berjuang meraih cita-cita.</p><p>Ironisny
            a kehidupan mereka, kejujuran pemikiran mereka, indahnya petualangan mereka, dan
             temukan diri Anda tertawa, menangis, dan tersentuh saat membaca setiap lembarny
            a. Buku ini dipersembahkan buat mereka yang meyakini the magic of childhood memo
            ries, dan khususnya juga buat siapa saja yang masih meyakini adanya pintu keajai
            ban lain untuk mengubah dunia pendidikan.</p>',
            'category_id' => 3,
            'user_id' => 1
        ]);
    }
}
