

<?php $__env->startSection('container'); ?>
  <arti>
    <h2><?php echo e($post["title"]); ?></h2>
    <h5><?php echo e($post["author"]); ?></h5>

    <p>By : Nabilla Nathafelya in <a href ="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a></p>


  <?php echo $post->body; ?>


  <a href="/posts">Back To Posts</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\applications\digital-library\resources\views/post.blade.php ENDPATH**/ ?>